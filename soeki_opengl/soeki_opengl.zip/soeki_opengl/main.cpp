// OpenGL tutorial main()
//
// Converted from the original Windows version.  See the README for details.

#include "App.h"

#include <stdlib.h>

int main( void )
{
	// Create our application object and go!
	App the_app;
	the_app.Run();

	// main() should always return something sensible.
	return EXIT_SUCCESS;
}
